# Paginated Reports Deployment Guide

This utility automates the deployment of standard product Paginated Reports (RDLs) into state-specific implementations. It modifies the underlying connection strings and table-valued function (TVF) schemas to point to your specific Databricks Unity Catalog environment.

## Package Contents
Ensure your deployment package contains the following items in the same directory:
*   **`deploy_reports.exe`**: The automated parser engine.
*   **`config.json`**: The configuration file you will modify.
*   **`source_reports/`**: A folder containing the raw, productized `.rdl` files from GitHub.

## Configuration Steps
Before running the executable, you must map the reports to your implementation's infrastructure.

1. Open `config.json` in any text editor (e.g., Notepad).
2. Locate the `deployment_target` section and input your Databricks SQL Warehouse details:
    *   `host`: Your Databricks workspace URL.
    *   `database`: Your specific Unity Catalog name (e.g., `oz_dev`).
    *   `http_path`: The specific compute endpoint for your SQL warehouse.
3. Locate the `schema_mapping` section:
    *   Leave `product_schema` exactly as it is.
    *   Update `implementation_schema` to match the exact schema where your TVFs are deployed (e.g., `illinois_silver_reports`).
4. Save and close the file. 

## Execution & Validation
Once the configuration is mapped, run the utility to generate your localized reports.

1. Double-click `deploy_reports.exe`.
2. A terminal window will appear, logging the successful parsing of each RDL file.
3. Navigate to the newly generated `deployed_reports/` folder.
4. Upload these `.rdl` files directly to your state-specific Power BI Service Workspace.
