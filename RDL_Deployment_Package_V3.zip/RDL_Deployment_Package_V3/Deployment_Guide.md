# Paginated Reports Deployment Guide (V3)

This utility automates the deployment of standard product Paginated Reports (RDLs) into state-specific implementations. 

## Package Contents
Ensure your deployment package contains the following items in the same directory:
*   **`deploy_reports.exe`**: The automated parser engine.
*   **`config.json`**: The configuration file you will modify.
*   **`source_reports/`**: A folder containing the raw, productized `.rdl` files.

## Configuration Steps
Before running the executable, you must map the reports to your implementation's infrastructure.

1. Open `config.json` in any text editor.
2. Update the 5 variables to match your environment:
    *   `databricks_host`: Your Databricks workspace URL.
    *   `databricks_http_path`: The compute endpoint for your SQL warehouse.
    *   `target_catalog`: Your state's Unity Catalog name (e.g., `illinois_prod`).
    *   `target_config_schema`: The schema containing `rpt_config_dim`.
    *   `target_tvf_schema`: The schema containing your TVFs.
3. Save and close the file. 

## Execution
1. Place all `.rdl` files into the `source_reports/` folder.
2. Double-click `deploy_reports.exe`.
3. Upload the generated `.rdl` files from the `deployed_reports/` folder directly to your Power BI Service Workspace.
